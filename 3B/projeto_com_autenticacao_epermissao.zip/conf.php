<?php
    include "conexao.php";
    
    $alt = "Descrição da imagem";
    $desenvolvedor = "Disciplina WEB - 3o Info Integrado";
    $menu = array(
                    "aluno"=>"Aluno",
                    "professor"=>"Professor",                    
                    "disciplina"=>"Disciplina",
                    "turma"=>"Turma"
                );
    

    include "cabecalho.php";
    include "rodape.php";

?>
